#!/bin/bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PART3_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

SCENE="${1:-Re10k-1}"
CONFIG="$PART3_ROOT/configs/project_gen_full.json"
EXTRA_ARGS=()
if [ "$#" -ge 2 ]; then
  if [[ "$2" == --* ]]; then
    EXTRA_ARGS=("${@:2}")
  else
    CONFIG="$2"
    EXTRA_ARGS=("${@:3}")
  fi
fi

python3 "$PART3_ROOT/apps/run_retention_experiment.py" \
  --config "$CONFIG" \
  --scene "$SCENE" \
  "${EXTRA_ARGS[@]}"
