#!/bin/bash

set -euo pipefail

MODEL_DIR="${1:-}"
if [ -z "$MODEL_DIR" ]; then
  echo "Usage: bash part3/scripts/eval_part3_3dgs.sh /abs/path/to/model_dir"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PART3_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJECT_ROOT="$(cd "$PART3_ROOT/.." && pwd)"
REPO="$PROJECT_ROOT/gaussian-splatting"
LOG_DIR="$MODEL_DIR/logs"
mkdir -p "$LOG_DIR"

cd "$REPO"

python3 render.py -m "$MODEL_DIR" --skip_train 2>&1 | tee "$LOG_DIR/render_test_console.log"
python3 metrics.py -m "$MODEL_DIR" 2>&1 | tee "$LOG_DIR/metrics_test_console.log"
